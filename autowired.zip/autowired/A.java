package autowired;

public class A {
	B b ;
   /* public B getB() {
		return b;
	}
	public void setB(B b) {
		this.b = b;
	}*/
	A(B b)
    {
    	this.b=b;
    }
void fun()
  {
	  b.fun1();
	  System.out.println("A");
  }
  
}
