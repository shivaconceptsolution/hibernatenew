package autowired;

public class B {
	 void fun1()
	  {
		  System.out.println("B");
	  }
}
