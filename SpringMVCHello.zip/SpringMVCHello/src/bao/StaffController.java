package bao;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StaffController {

	@RequestMapping("st")
	public String staffIndex()
	{
		return "staffview";
	}
}
