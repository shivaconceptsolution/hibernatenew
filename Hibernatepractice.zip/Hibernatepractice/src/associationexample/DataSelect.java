package associationexample;

import java.util.Iterator;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class DataSelect {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");

		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Object o = session.get(Vendor.class,new Integer(102));
		Vendor v = (Vendor)o;
		System.out.println(v.getVendorId());
		System.out.println(v.getVendorName());
		Set s = v.getChildren();
		Iterator it = s.iterator();
		while(it.hasNext())
		{
			Object o1 = it.next();
			Customer c1=(Customer)o1;
			System.out.println(c1.getCustomerId() + " "+ c1.getCustomerName());
		}
        session.close();
		

	}

}
