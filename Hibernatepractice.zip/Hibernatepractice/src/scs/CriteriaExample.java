package scs;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.ProjectionList;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

public class CriteriaExample {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Criteria c  = s.createCriteria(Student.class);
		ProjectionList p1=Projections.projectionList();
		 p1.add(Projections.property("rno"));
		p1.add(Projections.property("sname"));
		c.setProjection(p1);
		
		List ls = c.list();
		Iterator it = ls.iterator();
	
		while(it.hasNext())
		{
			Object arr[] = (Object[]) it.next();
			System.out.println(arr[0] + " " + arr[1]);
		}
	    s.close();


	}

}
