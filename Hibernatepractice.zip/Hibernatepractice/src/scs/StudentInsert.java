package scs;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.*;
public class StudentInsert {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
	
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		Student obj = new Student();
		System.out.println("Enter rno");
		obj.setRno(sc.nextInt());
		System.out.println("Enter name");
		obj.setSname(sc.next());
	    s.save(obj);
	    tx.commit();
	    s.close();
	    

	}

}
