package onetomany;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.*;
public class CustomerMain {
  public static void main(String args[])
  {
	  Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		Vendor v=new Vendor();
	    v.setVendorId(100);
	    v.setVendorName("java4s");
        Customer c1=new Customer();
	    c1.setCustomerId(500);
	    c1.setCustomerName("customer1");
        Customer c2=new Customer();
	    c2.setCustomerId(501);
	    c2.setCustomerName("customer2");
	    Set st=new HashSet();
	    st.add(c1);
	    st.add(c2);
	    v.setChildren(st);
	    s.save(v);
	    tx.commit();
	    s.close();
  }
}
