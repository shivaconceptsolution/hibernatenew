package scs;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class EmpMain {

	public static void main(String[] args) {
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");
		SessionFactory sf = cfg.buildSessionFactory();
		Session s = sf.openSession();
		Transaction tx = s.beginTransaction();
		Emp o = new Emp();
		o.setEmpid(1001);
		o.setEmpname("XYZ");
		o.setJob("Manager");
		o.setSalary(25000);
		s.save(o);
		tx.commit();
		s.close();

	}

}
